	<div id="Filters_List" class="dropdown" style="position:absolute;left:-1px;right:-1px;display:block;width:100%; top:21px;bottom:18px;overflow:auto;">
			<span id="Filters_Country" class="menuItem" onclick="processFilters(this)">Country</span>
			<span id="Filters_OS" class="menuItem" onclick="processFilters(this)">OS</span>
			<span id="Filters_Version" class="menuItem" onclick="processFilters(this)">Version</span>
			<span id="Filters_ID" class="menuItem" onclick="processFilters(this)">ID</span>
			<span id="Filters_IP" class="menuItem" onclick="processFilters(this)">IP</span>
	</div>
	<input type="text" id="Filters_Buffer" value="Use this value for the 'Filters' parameter." style="position:absolute;left:-1px;right:-1px;display:block;width:100%;bottom:-1px;" />
