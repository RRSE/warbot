<?php
	if(isset($_GET['command'])) {
		switch(strtolower($_GET['command']))
		{
			case "":
				// Lolwut		
				break;
			default:						
		}
	} else {
?>
	<form action="index.php?p=UIWindowHTTPFlood" method="get" onsubmit="return processHTTPFlood(this)">
		Target URL <input id="HTTPFlood_TargetURL" name="TargetURL" type="text" style="position:absolute;right:4px" /><br /><br />
		Duration (m) <input id="HTTPFlood_Duration" size="6" name="Duration" value="60" type="text" style="position:absolute;right:4px;text-align:right;" /><br /><br />
		Strength <input id="HTTPFlood_Strength" size="6" value="0%" name="Strength" type="text" style="position:absolute;right:4px;text-align:right;" />
		<div id="HTTPFlood_Strength_Slider" onclick="httpfloodstrength_Slider(event)" onmousemove="httpfloodstrength_SliderMove(event)" onmouseleave="httpfloodstrength_SliderEnd(event)" onmouseup="httpfloodstrength_SliderEnd(event)" onmousedown="httpfloodstrength_SliderBegin(event)" class="precipitationBGGray" style="float:right;position:relative;right:60px;/*top:-14px;left:75px;*/width:100px;"><div id="HTTPFlood_Strength_InnerSlider" class="curPrecipitation" style="width:1%;"></div></div>
		<br /><br />
		Bots<input id="HTTPFlood_Bots" size="6" name="Bots" type="text" value="0" style="position:absolute;right:4px;text-align:right;" />
		<div id="HTTPFlood_Bots_Slider" onclick="httpfloodbots_Slider(event)" onmousemove="httpfloodbots_SliderMove(event)" onmouseleave="httpfloodbots_SliderEnd(event)" onmouseup="httpfloodbots_SliderEnd(event)" onmousedown="httpfloodbots_SliderBegin(event)" class="precipitationBGGray" style="float:right;position:relative;right:60px;/*top:-14px;left:75px;*/width:100px;"><div id="HTTPFlood_Bots_InnerSlider" class="curPrecipitation" style="width:1%;"></div></div>
		<br /><br />
		<input id="cancelAttack" name="cancel" value="Cancel" type="button" style="position:absolute;right:25%;" onclick="hideWindow('httpflood')" /> <input id="submitAttack" name="submit" value="Attack" type="submit" style="position:absolute;left:25%;" />
	</form>

<?php
	}
?>