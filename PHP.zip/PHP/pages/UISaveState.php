<?php
	//Backend
	try {
		$Auth = new Auth();
		$Auth->RequireSession();
		$Auth->Ajax();
		$Auth->Validate(false);
	} catch(Exception $e) {
		die("fuck u faggot azuisleet");
	}
	if (isset($_POST["icon"])) {
		$Res = "OK";
		try {
			$Auth = new Auth();
			$Auth->Ajax();
			$Auth->RequireSession();
			$Auth->Validate();
			
			$UIState_Icons = array();
			//Expects an array of icons
			//icon[]=<iconname>:<x>:<y>[&icon[]=<iconname>:<x>:<y>...]
			//EG: icon[]=console:530:492&icon[]=botnet:103:482
			/**
			 * TODO:
			 * Perform more sanitization and validation!
			 **/
			foreach ($_POST["icon"] as $IconRaw) {
				$Icon = explode(":", $IconRaw);
				if (count($Icon) != 3)
					throw new Exception("Got incorrect number of results when splitting icon by colon.");
				$UIState_Icons[] = array("Icon" => $Icon[0], "X" => $Icon[1], "Y" => $Icon[2]);
			}
			
			$CUsr = User::$CUsr;
			$CUsr->UIState_Icons = $UIState_Icons;
		} catch (Exception $Ex) {
			$Res = $Ex->getMessage();
		}
		$this->Res = $Res;
	}
?>