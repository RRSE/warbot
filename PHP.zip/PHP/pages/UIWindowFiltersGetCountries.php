<?php
	$Override = array(
		"GROUP BY"	=>	"Country",
		"ORDER BY"	=>	"Country ASC");
	$Bots = Bot::Find($Override);
	
	$this->Bots = $Bots;
?>