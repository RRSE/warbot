var PageOffset=0;

function StatsUpdate() {
	$.ajax({
		async: true,
		url: "index.php?p=UIWindowStats&notemplate=1&PageOffset=" + PageOffset,
		type: "GET",
		success: function(data){
			if (data.substr(0, 2) == "NO") {
				return;
			}
			else {
				// YAY IT WORKED LOLZOZLZOl
				$("#Stats_Table").html(data);
				setTimeout("StatsUpdate()", 60000);
			}
			
		}
	});
}

function StatsNext() {
	PageOffset += 10;
	$.ajax({
		async: true,
		url: "index.php?p=UIWindowStats&notemplate=1&PageOffset=" + PageOffset,
		type: "GET",
		success: function(data){
			if (data.substr(0, 2) == "NO") {
				// Can't do! fuck it
				PageOffset -= 10;
				return;
			}
			else {
				// YAY IT WORKED LOLZOZLZOl
				$("#Stats_Table").html(data);
			}
		}
	});
}

function StatsPrevious() {
	if(PageOffset == 0) {
		return; // NO NEGATIVE OFFSET L0L
	}
	PageOffset -= 10;
	$.ajax({
		async: true,
		url: "index.php?p=UIWindowStats&notemplate=1&PageOffset=" + PageOffset,
		type: "GET",
		success: function(data){
			if (data.substr(0, 2) == "NO") {
				// Can't do! fuck it
				PageOffset += 10;
				return;
			}
			else {
				// YAY IT WORKED LOLZOZLZOl
				$("#Stats_Table").html(data);
			}
		}
	});
}
setTimeout("StatsUpdate()", 60000);
