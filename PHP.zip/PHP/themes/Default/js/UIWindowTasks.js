var TasksPageOffset=0;

function TasksNext() {
	TasksPageOffset += 10;
	$.ajax({
		async: true,
		url: "index.php?p=UIWindowTasks&notemplate=1&PageOffset=" + TasksPageOffset,
		type: "GET",
		success: function(data){
			if (data.substr(0, 2) == "NO") {
				// Can't do! fuck it
				TasksPageOffset -= 10;
				return;
			}
			else {
				// YAY IT WORKED LOLZOZLZOl
				$("#Tasks_Table").html(data);
			}
		}
	});
}

function TasksPrevious() {
	if(TasksPageOffset == 0) {
		return; // NO NEGATIVE OFFSET L0L
	}
	TasksPageOffset -= 10;
	$.ajax({
		async: true,
		url: "index.php?p=UIWindowTasks&notemplate=1&PageOffset=" + TasksPageOffset,
		type: "GET",
		success: function(data){
			if (data.substr(0, 2) == "NO") {
				// Can't do! fuck it
				TasksPageOffset += 10;
				return;
			}
			else {
				// YAY IT WORKED LOLZOZLZOl
				$("#Tasks_Table").html(data);
			}
		}
	});
}

function TasksRemove(id){
	var id = parseInt(id, 10);
	$.ajax({
		async: true,
		url: "index.php?p=UIWindowTasks&notemplate=1",
		type: "POST",
		data: {ID: id},
		success: function(data){
			if (data.substr(0, 2) == "OK") {
				TasksPageOffset -= 10;
				TasksNext();
				return;
			}
			else {
				alert(data);
			}
		}
	});
}
