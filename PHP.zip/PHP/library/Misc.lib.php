<?php
	function Require_Post_Vars($Vars) {
		foreach ($Vars as $Var) {
			if (!isset($_POST[$Var]))
				return false;
		}
		return true;
	}
?>